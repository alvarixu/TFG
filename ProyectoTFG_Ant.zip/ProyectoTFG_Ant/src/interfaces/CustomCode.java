/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author ivanr
 */
public interface CustomCode {
    
    /**
     * Method to write a console message
     * @param msg 
     */
    static void writeConsoleMSG(String msg) {
        System.out.println(msg);
    }
    
    /**
     * Extension of the original method. Allows to add
     * intents based in the integer parameter.
     * 
     * @param msg The message to show
     * @param intents The number of intents for the message.
     */
    static void writeConsoleMSG(String msg, int intents) {
        for (int i = 1; i <= intents; i++) {
            System.out.print("\t");
        }
        System.out.println(msg);
    }
    
    /**
     * Extension of the original method, Allows to indicate
     * if the message has an arrow poiting to the message at the 
     * begining of this one.
     * 
     * @param msg The message to show
     * @param arrowed If the message has an arrow
     */
    static void writeConsoleMSG(String msg, boolean arrowed) {
        if (arrowed) {
            System.out.println("---> " + msg);
        } else {
            System.out.println(msg);
        }
    }
    
    /**
     * Method that writes an empty line in the terminal
     */
    static void writeConsoleEmptyLine() {
        System.out.println("");
    }
    
    /**
     * Method to write error console error
     * @param msg 
     */
    static void writeConsoleErrorMSG(String msg) {
        System.err.println(msg);
    }
    
    /**
     * Method to write a line in console
     */
    static void writeConsoleLines() {
        System.out.println("================================================");
    }
    
    /**
     * Method to write a error line in console
     */
    static void writeConsoleErrorLines() {
        System.err.println("================================================");
    }
    
    /**
     * Method used to properly edit the XML file without visual glitches.
     * 
     * @param node You dont pass an actual node, but the XML doc object
     */
    static void deleteEmptyNodes(Node node) {
        NodeList hijos = node.getChildNodes();
        for (int i = hijos.getLength() - 1; i >= 0; i--) {
            Node childNode = hijos.item(i);
            
            if (childNode.getNodeType() == Node.TEXT_NODE && childNode.getNodeValue().trim().isEmpty()) {
                node.removeChild(childNode);
                
            } else if (childNode.hasChildNodes()) {
                deleteEmptyNodes(childNode);
            }
        }
    }
    
    /**
     * Method that returns a text capitalized
     * 
     * @param text Text to be capitalized
     * @return Capitalized text
     */
    static String capitalize(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }
        
        return text.substring(0, 1).toUpperCase() + text.substring(1);
    }
}
