/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces.names;

import java.io.File;

/**
 *
 * @author ivanr
 */
public interface Routes {
    
    String XML_FILES_ROUTE = "src" + File.separator + "resources" + File.separator + "xml";
    
    String IMG_BACKGROUNDS_ROUTE = "src" + File.separator + "resources" + File.separator + "img" + File.separator + "backgrounds";
    
    String IMG_ICONS_ROUTE = "src" + File.separator + "resources" + File.separator + "img" + File.separator + "icons";
    
}
