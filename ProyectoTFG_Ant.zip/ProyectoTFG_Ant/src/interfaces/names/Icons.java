/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces.names;

/**
 *
 * @author ivanr
 */
public interface Icons {
    
    String IMG_ICON_BB = "img_icon_bb.png";
    
}
