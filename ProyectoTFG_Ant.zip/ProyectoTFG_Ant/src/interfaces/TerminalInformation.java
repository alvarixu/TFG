/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * @author ivanr
 */
public interface TerminalInformation {
    
    /**
     * Method used in frames and dialogs to indicate,
     * in the terminal, that a button was used.
     * 
     * @param buttonActionCommand Action command of the button.
     */
    static void buttonActioned(String buttonActionCommand) {
        CustomCode.writeConsoleLines();
        CustomCode.writeConsoleMSG("Button actioned -> " + buttonActionCommand);
        CustomCode.writeConsoleEmptyLine();
    }
    
    /**
     * Method used in frames and dialogs to indicate,
     * in the terminal, that a menuItem was used.
     * 
     * @param menuItemActionCommand Action command of the menuItem.
     */
    static void menuItemActioned(String menuItemActionCommand) {
        CustomCode.writeConsoleLines();
        CustomCode.writeConsoleMSG("MenuItem actioned -> " + menuItemActionCommand);
        CustomCode.writeConsoleEmptyLine();
    }
    
    /**
     * Method used in frames and dialogs to indicate,
     * in the terminal, that a checkBoxMenuItem was used.
     * 
     * @param checkBoxMenuItemActionCommand Action command of the checkBoxMenuItem.
     */
    static void checkBoxMenuItemActioned(String checkBoxMenuItemActionCommand) {
        CustomCode.writeConsoleLines();
        CustomCode.writeConsoleMSG("CheckBoxMenuItem actioned -> " + checkBoxMenuItemActionCommand);
        CustomCode.writeConsoleEmptyLine();
    }
}
